<?php
 return [
"brands" => "Marcas",
"manage_your_brands" => "Gerenciar suas marcas",
"all_your_brands" => "Todas as suas marcas",
"note" => "Nota",
"brand_name" => "nome da marca",
"short_description" => "Breve descrição",
"added_success" => "Marca adicionada com sucesso",
"updated_success" => "Marca atualizada com sucesso",
"deleted_success" => "Marcar excluído com sucesso",
"add_brand" => "Adicionar marca",
"edit_brand" => "Editar marca",
];
