<?php
 return [
"units" => "इकाइयों",
"manage_your_units" => "अपनी इकाइयां प्रबंधित करें",
"all_your_units" => "आपके सभी इकाइयां",
"name" => "नाम",
"short_name" => "संक्षिप्त नाम",
"allow_decimal" => "दशमलव की अनुमति दें",
"added_success" => "यूनिट सफलतापूर्वक जोड़ा",
"updated_success" => "यूनिट सफलतापूर्वक अद्यतन",
"deleted_success" => "यूनिट सफलतापूर्वक हटा दी",
"add_unit" => "इकाई जोड़ें",
"edit_unit" => "यूनिट संपादित करें",
];
